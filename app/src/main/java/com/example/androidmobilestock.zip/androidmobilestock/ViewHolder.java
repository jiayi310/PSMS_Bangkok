package com.example.androidmobilestock;

import android.view.View;

import androidx.annotation.NonNull;

public interface ViewHolder {
    void onClick(@NonNull View v);
}
