package com.example.androidmobilestock.widget;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.androidmobilestock.R;

public class BatchNo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batch_no);
    }
}