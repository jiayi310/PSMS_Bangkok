package com.example.androidmobilestock.Model;

import java.util.ArrayList;
import java.util.List;

public class BarChart2 {
    public BarChart2() {
        DebtorArray = new ArrayList<>();
        QtyArray = new ArrayList<>();
    }

    public List<String> DebtorArray;
    public List<String> QtyArray;

}
